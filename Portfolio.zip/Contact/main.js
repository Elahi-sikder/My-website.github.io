$(document).ready(function (){
  
  
  $('.icon').click(function (){
    $('.list').show('slow')
  });
  
  $('.closed').click(function (){
    $('.list').hide('slow')
  })
})