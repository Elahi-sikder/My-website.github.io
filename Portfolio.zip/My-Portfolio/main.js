$(document).ready(function() {
  

/*...... */
  $('.icon').click(function() {
    $('.list').show('slow')
  });

  $('.closed').click(function() {
    $('.list').hide('slow')
  });
 
  $('.control-carousel').click(function (){
  $('.carousel').toggle()
}) ;



$('.photo a').simpleLightbox({
  
});


})


